# Instructor Script — Module 3 Lesson 1: Zapier/Make reliability patterns

Intro → Concepts → Demo → Exercise → Recap.
