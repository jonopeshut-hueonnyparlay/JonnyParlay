# Instructor Script — Module 7 Lesson 1: Turn workflows into SOPs and checklists

Intro → Concepts → Demo → Exercise → Recap.
