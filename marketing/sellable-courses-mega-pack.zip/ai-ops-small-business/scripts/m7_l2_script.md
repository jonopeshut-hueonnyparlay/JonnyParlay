# Instructor Script — Module 7 Lesson 2: VA delegation & QA loops

Intro → Concepts → Demo → Exercise → Recap.
