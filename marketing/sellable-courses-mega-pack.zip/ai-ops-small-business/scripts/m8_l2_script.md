# Instructor Script — Module 8 Lesson 2: Uptime monitors and error alerts

Intro → Concepts → Demo → Exercise → Recap.
