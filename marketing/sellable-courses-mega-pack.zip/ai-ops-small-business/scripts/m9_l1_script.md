# Instructor Script — Module 9 Lesson 1: Ship an automation bundle that saves 10+ hours/week

Intro → Concepts → Demo → Exercise → Recap.
