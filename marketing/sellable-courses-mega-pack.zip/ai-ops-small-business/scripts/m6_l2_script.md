# Instructor Script — Module 6 Lesson 2: Receipt extraction + monthly report pack

Intro → Concepts → Demo → Exercise → Recap.
