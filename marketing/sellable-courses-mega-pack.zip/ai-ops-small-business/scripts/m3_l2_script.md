# Instructor Script — Module 3 Lesson 2: Retries, alerts, and idempotency

Intro → Concepts → Demo → Exercise → Recap.
