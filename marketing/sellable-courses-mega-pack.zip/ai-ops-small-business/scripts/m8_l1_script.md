# Instructor Script — Module 8 Lesson 1: PII handling, access control, backups

Intro → Concepts → Demo → Exercise → Recap.
