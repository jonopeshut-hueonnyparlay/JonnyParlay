# Instructor Script — Module 4 Lesson 1: Airtable/Notion schemas (leads, tasks, invoices)

Intro → Concepts → Demo → Exercise → Recap.
