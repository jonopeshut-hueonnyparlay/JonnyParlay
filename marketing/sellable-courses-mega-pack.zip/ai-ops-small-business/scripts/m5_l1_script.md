# Instructor Script — Module 5 Lesson 1: Auto-responders that route, tag, summarize

Intro → Concepts → Demo → Exercise → Recap.
