# Instructor Script — Module 2 Lesson 2: Build email/ticket triage with human-in-the-loop

Intro → Concepts → Demo → Exercise → Recap.
