# Instructor Script — Module 1 Lesson 2: Stack overview: assistants, triggers, actions, data

Intro → Concepts → Demo → Exercise → Recap.
