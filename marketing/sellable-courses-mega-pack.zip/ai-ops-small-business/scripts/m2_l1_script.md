# Instructor Script — Module 2 Lesson 1: Design prompt systems and tool calls

Intro → Concepts → Demo → Exercise → Recap.
