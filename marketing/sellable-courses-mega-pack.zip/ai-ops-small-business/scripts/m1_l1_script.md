# Instructor Script — Module 1 Lesson 1: Find automation candidates and estimate hours saved

Intro → Concepts → Demo → Exercise → Recap.
