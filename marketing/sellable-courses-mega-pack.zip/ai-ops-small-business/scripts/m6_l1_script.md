# Instructor Script — Module 6 Lesson 1: Invoice creation, reminders, reconciliation

Intro → Concepts → Demo → Exercise → Recap.
