# Instructor Script — Module 4 Lesson 2: Sync hygiene and reconciliation

Intro → Concepts → Demo → Exercise → Recap.
