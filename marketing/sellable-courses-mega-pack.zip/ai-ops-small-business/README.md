# AI Ops for Small Businesses: Automate 80% of Back Office in 30 Days

**Audience:** Owners/operators (1–50 employees), agency owners, solo entrepreneurs  
**Outcome:** Identify, design, and deploy automations that reliably save 10+ hours/week across admin, customer ops, and finance—without engineering.  
**Format:** 30-day plan • Video-first lessons + SOPs + worksheets + templates + capstone
