# Slides Outline — Module 3 Lesson 2: Retries, alerts, and idempotency

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
