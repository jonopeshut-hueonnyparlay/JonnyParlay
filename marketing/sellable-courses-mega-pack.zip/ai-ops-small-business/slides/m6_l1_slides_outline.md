# Slides Outline — Module 6 Lesson 1: Invoice creation, reminders, reconciliation

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
