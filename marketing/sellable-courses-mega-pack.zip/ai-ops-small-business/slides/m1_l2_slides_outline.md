# Slides Outline — Module 1 Lesson 2: Stack overview: assistants, triggers, actions, data

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
