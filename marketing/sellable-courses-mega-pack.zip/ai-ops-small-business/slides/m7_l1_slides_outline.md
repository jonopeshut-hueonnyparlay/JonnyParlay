# Slides Outline — Module 7 Lesson 1: Turn workflows into SOPs and checklists

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
