# Slides Outline — Module 2 Lesson 1: Design prompt systems and tool calls

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
