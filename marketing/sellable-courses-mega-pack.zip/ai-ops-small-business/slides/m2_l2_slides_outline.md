# Slides Outline — Module 2 Lesson 2: Build email/ticket triage with human-in-the-loop

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
