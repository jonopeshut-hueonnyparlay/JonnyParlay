# Slides Outline — Module 4 Lesson 1: Airtable/Notion schemas (leads, tasks, invoices)

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
