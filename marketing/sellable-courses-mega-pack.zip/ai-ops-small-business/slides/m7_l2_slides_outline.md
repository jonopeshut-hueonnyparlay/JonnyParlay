# Slides Outline — Module 7 Lesson 2: VA delegation & QA loops

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
