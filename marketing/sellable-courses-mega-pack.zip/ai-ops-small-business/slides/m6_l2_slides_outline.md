# Slides Outline — Module 6 Lesson 2: Receipt extraction + monthly report pack

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
