# Slides Outline — Module 8 Lesson 2: Uptime monitors and error alerts

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
