# Slides Outline — Module 1 Lesson 1: Find automation candidates and estimate hours saved

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini-Exercise
- Summary
