# Sports Betting Analytics Bootcamp: From Zero to Model-Driven in 4 Weeks

**Audience:** Aspiring bettors, DFS players, analysts  
**Outcome:** Build a basic model, find pricing edges vs. sportsbook lines, execute disciplined staking, and track ROI/CLV responsibly.  
**Format:** 4 weeks • 6–8 hrs/week • Video-first lessons (5–12 min) + worksheets + quizzes + capstone  
**Disclaimer:** Educational content. No guarantees of profit; gamble responsibly.
