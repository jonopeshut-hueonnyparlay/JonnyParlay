# Instructor Script — Module 2 Lesson 3: Bet log structure; grading and ROI math

Intro → Concepts → Demo → Exercise → Recap.
