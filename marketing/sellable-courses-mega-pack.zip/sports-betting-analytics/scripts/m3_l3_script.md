# Instructor Script — Module 3 Lesson 3: Feature engineering & backtesting

Intro → Concepts → Demo → Exercise → Recap.
