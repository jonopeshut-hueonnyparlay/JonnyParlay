# Instructor Script — Module 3 Lesson 4: Calibration & decision thresholds

Intro → Concepts → Demo → Exercise → Recap.
