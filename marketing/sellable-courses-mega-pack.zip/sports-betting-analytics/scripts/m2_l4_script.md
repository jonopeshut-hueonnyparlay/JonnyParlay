# Instructor Script — Module 2 Lesson 4: Execution checklist & tilt management

Intro → Concepts → Demo → Exercise → Recap.
