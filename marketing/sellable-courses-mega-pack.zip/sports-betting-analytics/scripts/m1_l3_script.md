# Instructor Script — Module 1 Lesson 3: Variance, drawdowns, risk of ruin

Intro → Concepts → Demo → Exercise → Recap.
