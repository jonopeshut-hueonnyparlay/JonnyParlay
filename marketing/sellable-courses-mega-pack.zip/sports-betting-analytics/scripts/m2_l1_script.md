# Instructor Script — Module 2 Lesson 1: Sources; scraping etiquette; CSV hygiene

Intro → Concepts → Demo → Exercise → Recap.
