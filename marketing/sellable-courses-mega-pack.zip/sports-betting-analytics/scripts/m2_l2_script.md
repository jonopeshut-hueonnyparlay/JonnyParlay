# Instructor Script — Module 2 Lesson 2: Odds snapshots, line movement, closing line value (CLV)

Intro → Concepts → Demo → Exercise → Recap.
