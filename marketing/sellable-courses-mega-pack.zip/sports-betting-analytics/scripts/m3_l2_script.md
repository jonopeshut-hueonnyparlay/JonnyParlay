# Instructor Script — Module 3 Lesson 2: Poisson models for scoring

Intro → Concepts → Demo → Exercise → Recap.
