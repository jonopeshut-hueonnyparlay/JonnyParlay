# Instructor Script — Module 1 Lesson 1: Odds formats & implied probability (US/Dec/Fractional)

Intro → Concepts → Demo → Exercise → Recap.
