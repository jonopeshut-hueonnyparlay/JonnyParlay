# Instructor Script — Module 4 Lesson 1: Multi-book price shopping; timing & limits

Intro → Concepts → Demo → Exercise → Recap.
