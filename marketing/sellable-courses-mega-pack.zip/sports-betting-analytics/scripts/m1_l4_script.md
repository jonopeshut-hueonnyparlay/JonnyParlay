# Instructor Script — Module 1 Lesson 4: Kelly criterion & staking plans (fixed, % bankroll, Kelly-fraction)

Intro → Concepts → Demo → Exercise → Recap.
