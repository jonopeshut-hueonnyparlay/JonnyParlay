# Instructor Script — Module 4 Lesson 2: Risk controls; unit discipline

Intro → Concepts → Demo → Exercise → Recap.
