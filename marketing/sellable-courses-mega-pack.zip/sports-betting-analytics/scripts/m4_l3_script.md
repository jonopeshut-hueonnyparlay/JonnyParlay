# Instructor Script — Module 4 Lesson 3: Post‑mortems; iteration cadence

Intro → Concepts → Demo → Exercise → Recap.
