# Instructor Script — Module 1 Lesson 2: Removing vig / fair odds & expected value

Intro → Concepts → Demo → Exercise → Recap.
