# Instructor Script — Module 4 Lesson 4: Capstone rubric walkthrough

Intro → Concepts → Demo → Exercise → Recap.
