# Instructor Script — Module 3 Lesson 1: Logistic regression for binary outcomes

Intro → Concepts → Demo → Exercise → Recap.
