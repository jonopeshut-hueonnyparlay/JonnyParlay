# Slides Outline — Module 2 Lesson 3: Bet log structure; grading and ROI math

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
