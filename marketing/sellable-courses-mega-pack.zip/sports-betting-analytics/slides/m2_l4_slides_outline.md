# Slides Outline — Module 2 Lesson 4: Execution checklist & tilt management

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
