# Slides Outline — Module 3 Lesson 4: Calibration & decision thresholds

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
