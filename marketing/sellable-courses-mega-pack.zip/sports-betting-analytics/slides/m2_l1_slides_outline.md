# Slides Outline — Module 2 Lesson 1: Sources; scraping etiquette; CSV hygiene

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
