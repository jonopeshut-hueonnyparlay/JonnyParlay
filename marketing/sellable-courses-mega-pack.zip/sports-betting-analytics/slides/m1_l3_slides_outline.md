# Slides Outline — Module 1 Lesson 3: Variance, drawdowns, risk of ruin

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
