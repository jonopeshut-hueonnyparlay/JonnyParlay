# Slides Outline — Module 4 Lesson 3: Post‑mortems; iteration cadence

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
