# Slides Outline — Module 4 Lesson 2: Risk controls; unit discipline

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
