# Slides Outline — Module 1 Lesson 4: Kelly criterion & staking plans (fixed, % bankroll, Kelly-fraction)

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
