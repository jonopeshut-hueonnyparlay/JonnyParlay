# Slides Outline — Module 3 Lesson 3: Feature engineering & backtesting

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
