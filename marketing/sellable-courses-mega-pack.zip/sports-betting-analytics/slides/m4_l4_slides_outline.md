# Slides Outline — Module 4 Lesson 4: Capstone rubric walkthrough

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
