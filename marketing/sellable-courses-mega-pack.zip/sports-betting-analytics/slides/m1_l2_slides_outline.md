# Slides Outline — Module 1 Lesson 2: Removing vig / fair odds & expected value

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
