# Slides Outline — Module 4 Lesson 1: Multi-book price shopping; timing & limits

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
