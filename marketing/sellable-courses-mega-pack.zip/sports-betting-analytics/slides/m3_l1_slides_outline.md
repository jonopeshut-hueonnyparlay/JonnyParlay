# Slides Outline — Module 3 Lesson 1: Logistic regression for binary outcomes

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
