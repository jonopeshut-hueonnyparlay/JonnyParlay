# Slides Outline — Module 3 Lesson 2: Poisson models for scoring

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
