# Slides Outline — Module 1 Lesson 1: Odds formats & implied probability (US/Dec/Fractional)

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
