# Slides Outline — Module 2 Lesson 2: Odds snapshots, line movement, closing line value (CLV)

- Hook
- Key Concepts
- Live Walkthrough
- Pitfalls
- Mini‑Exercise
- Summary
