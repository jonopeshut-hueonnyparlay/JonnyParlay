# Promo Video Script (60–75 seconds)

**[0–3s Hook]** Sports betting *without* a process is just luck. This course gives you a disciplined, math-first system.

**[3–15s Outcome]** In four weeks you’ll build a simple model, price markets, and track CLV—so your decisions get sharper over time.

**[15–35s What’s Inside]** We cover EV, removing vig, Kelly sizing, CLV tracking, and a baseline logistic/Poisson approach. You’ll get worksheets, notebooks, and a capstone where you run a two-week test and present your results.

**[35–55s Credibility]** I teach a process rooted in probability and record-keeping—not hype or picks. You’ll leave with a workflow you can repeat and improve.

**[55–70s CTA]** If you want disciplined, data-driven betting, enroll now and start Week 1 today.
