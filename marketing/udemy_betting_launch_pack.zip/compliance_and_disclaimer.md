# Compliance & Responsible Gambling

- Educational content only. No guarantees of profit. Past performance ≠ future results.
- Follow local laws; access sportsbooks only where legal. Age 21+ (or local legal age) recommended.
- Nothing here is investment or financial advice. Use strict bankroll limits and seek help if gambling becomes harmful (see local helplines).

**On Udemy:** avoid external links to paid products/services; keep messaging educational and within Trust & Safety guidelines. Avoid spammy or misleading claims.
