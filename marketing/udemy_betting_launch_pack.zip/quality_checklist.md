# Udemy Upload-Day Checklist

- [ ] Minimum 30+ minutes of video, 5+ lectures total
- [ ] 720p+ video (16:9), clear audio, loudness consistent
- [ ] Course image 2048×1152 uploaded
- [ ] Landing page completed: title, subtitle, description, 6+ learn bullets
- [ ] Target audience & requirements filled
- [ ] At least one quiz and one assignment per section
- [ ] Resources attached (worksheets, CSVs, notebooks)
- [ ] Promo video uploaded (60–75s)
- [ ] Price set + coupons created (referral link generated)
- [ ] Educational announcement scheduled for week 2
