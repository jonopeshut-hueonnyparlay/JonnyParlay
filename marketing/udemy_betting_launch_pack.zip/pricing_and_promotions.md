# Pricing & Promotions Plan (Udemy)

- List price: $89.99 (fits common Udemy pricing bands; marketplace runs frequent discounts).
- Launch coupons:
  - INSTRUCTOR97 (30 days): $14.99 for your list to maximize 97% instructor share via referral.
  - ALUM20 (evergreen): 20% off for returning students.
- Announcements: 2 promotional emails per course per month. Use once at launch, once at day-10 “last chance”. Send educational announcements monthly with bonus lessons or worksheets.
- Revenue share: Expect 97% share on your own referrals, ~37% on organic marketplace sales.
