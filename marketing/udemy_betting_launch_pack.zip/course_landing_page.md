# Udemy Course Landing Page

**Title:** Sports Betting Analytics Bootcamp: EV, CLV & Modeling (4 Weeks)

**Subtitle:** Learn disciplined, data-driven betting: bankroll math, fair odds, CLV, basic models, and a repeatable review system.

## Description
This practical bootcamp teaches you how to think and operate like a disciplined, model-driven bettor.
Across four focused modules you’ll master the math that underpins profitable decision-making (EV, implied probability, removing vig, Kelly),
track your performance and CLV, and build a simple baseline model to price markets responsibly.

What this course is NOT: a “get rich quick” system, tout picks, or guarantees. It’s an educational program that helps you build a process.

## What you'll learn
- Convert American/decimal/fractional odds and remove the vig to get fair probabilities
- Calculate expected value (EV), variance, drawdowns, and apply fractional Kelly sizing
- Track bets, grade results, and measure Closing Line Value (CLV) properly
- Build a basic logistic/Poisson model to estimate win probabilities or scoring
- Design a tidy workflow and review cadence that reduces tilt and errors
- Execute with discipline: price shopping, timing, limits, and risk controls

## Requirements
- Basic comfort with spreadsheets (Excel or Google Sheets)
- Optional: beginner Python familiarity (provided notebooks are guided)
- Access to legal sportsbooks in your jurisdiction (for practice only)
- Commitment to responsible gambling and local laws

## Who this course is for
- Aspirational bettors and DFS players who want a structured, math-first process
- Analytically curious sports fans who want to understand pricing and edges
- Junior data analysts looking for a hands-on sports analytics project

