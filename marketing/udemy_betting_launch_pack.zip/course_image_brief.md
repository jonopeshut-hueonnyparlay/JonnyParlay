# Course Image Brief (Udemy Specs)

- Canvas: 2048×1152 px (16:9). Minimum acceptable is 750×422 px; create at higher resolution for quality.
- Style: Clean, bold title. Neutral background with subtle graph/odds motif. No claims like “Win Money Fast”. No bookmaker logos.
- Safe area: Keep key text centered; avoid edges. Export PNG and JPG variants.
- Variants: A/B test dark vs. light background once published.
