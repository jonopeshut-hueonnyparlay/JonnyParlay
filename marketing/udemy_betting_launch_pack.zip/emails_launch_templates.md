# Launch Email Templates (for Udemy promotions)

## Email 1 — Launch (Referral Link)
Subject: New: Sports Betting Analytics Bootcamp (launch coupon inside)

- Why: disciplined, data-driven system (not picks)
- What: 4 weeks, worksheets, notebooks, capstone
- Coupon: {REFERRAL_LINK}
- Scarcity: 48-hour coupon

## Email 2 — Last Chance
Subject: Last chance: launch coupon expires tonight

- Quick recap of outcomes
- One screenshot of worksheet or notebook
- Coupon: {REFERRAL_LINK}
- FAQ link + refund reminder
